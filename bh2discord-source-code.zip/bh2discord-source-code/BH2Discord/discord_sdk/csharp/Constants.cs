﻿using System;

namespace Discord
{
    static class Constants
    {
        public const string DllName = "discord_game_sdk";
    }
}
